
/*
*	Global variables
*/
var colors = d3.scale.category10().range();

/*
*	Helper functions
*/

function log(msg){
	console.log(msg);
}

function date_sort_asc (date1, date2) {
    if (date1.timestamp > date2.timestamp) return 1;
    if (date1.timestamp < date2.timestamp) return -1;
    return 0;
};